<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>yt-formatted-string_Cats are so funny you w_a20036</name>
   <tag></tag>
   <elementGuidId>3342aeca-cc06-4138-a951-6d4383b6a3c2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='video-title']/yt-formatted-string</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>yt-formatted-string</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>style-scope ytd-video-renderer</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>Cats are so funny you will die laughing - Funny cat compilation by Tiger Productions 3 years ago 10 minutes 80,590,107 views</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Cats are so funny you will die laughing - Funny cat compilation</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-manager&quot;)/ytd-search[@class=&quot;style-scope ytd-page-manager&quot;]/div[@id=&quot;container&quot;]/ytd-two-column-search-results-renderer[@class=&quot;style-scope ytd-search&quot;]/div[@id=&quot;primary&quot;]/ytd-section-list-renderer[@class=&quot;style-scope ytd-two-column-search-results-renderer&quot;]/div[@id=&quot;contents&quot;]/ytd-item-section-renderer[@class=&quot;style-scope ytd-section-list-renderer&quot;]/div[@id=&quot;contents&quot;]/ytd-video-renderer[@class=&quot;style-scope ytd-item-section-renderer&quot;]/div[@id=&quot;dismissable&quot;]/div[@class=&quot;text-wrapper style-scope ytd-video-renderer&quot;]/div[@id=&quot;meta&quot;]/div[@id=&quot;title-wrapper&quot;]/h3[@class=&quot;title-and-badge style-scope ytd-video-renderer&quot;]/a[@id=&quot;video-title&quot;]/yt-formatted-string[@class=&quot;style-scope ytd-video-renderer&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//a[@id='video-title']/yt-formatted-string</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add to queue'])[1]/following::yt-formatted-string[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tiger Productions'])[1]/preceding::yt-formatted-string[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='•'])[34]/preceding::yt-formatted-string[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Cats are so funny you will die laughing - Funny cat compilation']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/h3/a/yt-formatted-string</value>
   </webElementXpaths>
</WebElementEntity>
